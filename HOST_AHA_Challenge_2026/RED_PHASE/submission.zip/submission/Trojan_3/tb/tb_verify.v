
module tb_verify;
    reg clk, reset_n, init, next;
    reg [255:0] key;
    reg [127:0] block;
    wire [127:0] result;
    wire ready;

    aes_core dut (
        .clk(clk), .reset_n(reset_n), .encdec(1'b1), .init(init), .next(next),
        .key(key), .keylen(1'b1), .block(block), .result(result), .ready(ready)
    );

    initial begin clk = 0; forever #5 clk = ~clk; end

    initial begin
        reset_n = 0; init = 0; next = 0;
        key = 256'h0123456789ABCDEF0123456789ABCDEF00000000000000000000000000000000;
        #20 reset_n = 1;

        $display("--- PHASE 1: Functional Check ---");
        block = 128'hFFFFFFFF_FFFFFFFF_FFFFFFFF_FFFFFFFF;
        init = 1; #10 init = 0; next = 1;
        wait(ready); #10 next = 0;
        $display("Output: %x", result);

        $display("\n--- PHASE 2: Triggering Rare-Event SCA Leak ---");
        force dut.lfsr_reg = 16'h8000; 
        init = 1; #10 init = 0; next = 1;
        #5 $display("Active Leak Status: %b", dut.sca_leak);
        wait(ready);
        
        if (dut.sca_leak && result == 128'h69c4e0d86a7b0430d8cdb78070b4c55a) 
            $display("\n[SUCCESS] Trojan is transparent but active.");
        $finish;
    end
endmodule
